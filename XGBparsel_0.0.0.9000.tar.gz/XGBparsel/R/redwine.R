#' @title  redwine quality data
#'
#' @description A red wine quality data containing information of redwine
#' @format A data frame with 1599 rows and 12 variable
#'
"redwine"
