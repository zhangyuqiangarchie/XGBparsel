#' @title  a simulation data
#'
#' @description A simulation data which is used to be an example
#' @format An object of class matrix (inherits from array)
#'        with 300 rows and 501 columns.
"dataset"
